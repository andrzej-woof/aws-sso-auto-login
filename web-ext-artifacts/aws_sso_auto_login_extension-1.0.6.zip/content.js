// This script is intentionally left blank as we are using executeScript in background.js
